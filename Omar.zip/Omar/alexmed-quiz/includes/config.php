<?php
// عدّل القيم حسب XAMPP/WAMP لديك
define('DB_HOST', 'localhost');
define('DB_NAME', 'med_quiz');
define('DB_USER', 'root');
define('DB_PASS', ''); // في XAMPP عادةً فارغة